package com.example.chap08_27p_ex1;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

class MyView extends View {

    private int scale=0;
    Bitmap b;
    Bitmap mb;
    Bitmap sb;
    Matrix m = new Matrix();

    public MyView(Context context) {
        super(context);
        setBackgroundColor(Color.YELLOW);
        b = BitmapFactory.decodeResource(getResources(), R.drawable.house);
        mb = b;
        m.preScale(1,-1);
    }

    @Override
    protected void onDraw(Canvas canvas) {

        ++scale;
        if(scale>400) {
            scale=1;
            mb= Bitmap.createBitmap(b,0,0,b.getWidth(),b.getHeight(),m,false);
        }
        sb = Bitmap.createScaledBitmap(mb, scale, scale, false);
        canvas.drawBitmap(b, 0, 0 , null);
        canvas.drawBitmap(sb, 100, 100 , null);

        invalidate();
    }
}

/*
* @Override
    protected void onDraw(Canvas canvas) {
        canvas.drawColor(Color.YELLOW);
        canvas.drawRect(mBigOval, mFramePaint);
        canvas.drawArc(mBigOval, mStart, mSweep, true, mPaints);

        mSweep += SWEEP_INC;
        if (mSweep > 360) {
            mSweep -= 360;
            mStart += START_INC;
            if(mStart >= 360) {
                mStart -= 360;
            }
        }
        invalidate();
    }
* */

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(new MyView(this));
    }
}
