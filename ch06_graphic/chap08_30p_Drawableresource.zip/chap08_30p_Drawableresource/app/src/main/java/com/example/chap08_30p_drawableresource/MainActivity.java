package com.example.chap08_30p_drawableresource;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    LinearLayout mLinearLayout;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mLinearLayout = new LinearLayout(this);
        ImageView i = new ImageView(this);
        i.setImageDrawable(getResources().getDrawable(R.drawable.circleobj));
        i.setMinimumHeight(100);
        i.setMinimumWidth(100);
        mLinearLayout.addView(i);
        setContentView(mLinearLayout);
    }

}
