package com.example.user.ch06_surfaceview_56p;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Display;

public class MainActivity extends AppCompatActivity {
    MySurfaceView view;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        Ball.WIDTH = size.x;
        Ball.HEIGHT = size.y;

        view = new MySurfaceView(this);

        setContentView(view);
    }
}

class Ball {
    int x,y,xlnc = 1, ylnc = 1;
    int radius;
    static int WIDTH = 1080, HEIGHT = 1920;

    public Ball() {
        radius = WIDTH/20;

        x=(int) (Math.random()*(WIDTH-radius));
        y=(int) (Math.random()*(HEIGHT-radius));
        x = x < radius ? radius : x;
        y = y < radius ? radius : y;

        xlnc = (int)(Math.random()*30 + 1);
        ylnc = (int)(Math.random()*30 + 1);

    }

    public void paint(Canvas g) {
        Paint paint = new Paint();
        if(x < radius || x > (WIDTH - radius))
            xlnc = -xlnc;
        if(y < radius || y > (HEIGHT - radius))
            ylnc = -ylnc;

        x+=xlnc;
        y+=ylnc;

        paint.setColor(Color.RED);
        g.drawCircle(x,y,radius,paint);
    }
}



